'use client';

import { useState, useEffect } from 'react';
import Sidebar from '@/components/layout/sidebar';
import TopBar from '@/components/layout/topbar';
import MainContent from '@/components/layout/main-content';
import RightPanel from '@/components/layout/right-panel';
import MobileBottomNav from '@/components/layout/mobile-bottom-nav';
import ChatPage from '@/components/pages/chat-page';
import { useMobile } from '@/lib/use-mobile';

export default function Home() {
  const [selectedToken, setSelectedToken] = useState('PEPEFUN');
  const [isMounted, setIsMounted] = useState(false);
  const [mobileTab, setMobileTab] = useState('markets');
  const isMobile = useMobile();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null;

  const handleSidebarClick = (label: string) => {
    if (label === 'chat') {
      setMobileTab('chat')
    }
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Left Sidebar - Hidden on mobile, visible on md and up */}
      <div className="hidden md:flex">
        <Sidebar onMenuClick={handleSidebarClick} />
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <TopBar />

        {/* Content Grid - Responsive */}
        <div className="flex-1 flex gap-0.5 overflow-hidden p-0.5 pb-20 md:pb-0.5 flex-col md:flex-row">
          {/* Show main content unless on mobile with chat selected */}
          {!(isMobile && mobileTab === 'chat') && (
            <>
              {/* Center Content */}
              <MainContent selectedToken={selectedToken} setSelectedToken={setSelectedToken} />

              {/* Right Panel - Conditions based on screen size and tab selection */}
              {mobileTab === 'chat' && !isMobile ? (
                <div className="hidden lg:flex">
                  <ChatPage />
                </div>
              ) : (mobileTab === 'prediction' || mobileTab === 'battle') && isMobile ? (
                <div className="w-full">
                  <RightPanel selectedToken={selectedToken} />
                </div>
              ) : (
                <div className="hidden lg:flex">
                  <RightPanel selectedToken={selectedToken} />
                </div>
              )}
            </>
          )}

          {/* Show chat on mobile when selected */}
          {isMobile && mobileTab === 'chat' && (
            <ChatPage />
          )}
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav activeTab={mobileTab} onTabChange={setMobileTab} />
    </div>
  );
}
